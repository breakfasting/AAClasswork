import React from 'react';
import TodoListContainer from './todos/todo_list_container'
const App = function () {
    return (
        <TodoListContainer />
    )
}

export default App;